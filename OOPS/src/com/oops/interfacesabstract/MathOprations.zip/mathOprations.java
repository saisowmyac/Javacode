package com.oops.interfacesabstract;

public interface mathOprations {
	public abstract double squareRoot(int a);
	public abstract double powreOf(int a,int b);

}
